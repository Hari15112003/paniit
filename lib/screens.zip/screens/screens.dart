import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import 'package:name/utilities/utils.dart';
import 'package:name/widgets/progress.dart';
import 'package:name/widgets/timecontroller.dart';
import 'package:name/widgets/timeoptions.dart';
import 'package:name/widgets/timercard.dart';
import 'package:provider/provider.dart';

import '../widgets/chess.dart';
import '../widgets/playit.dart';
import '../widgets/timrservice.dart';
import '../widgets/xogame.dart';

class PromodoroScreen extends StatefulWidget {
  const PromodoroScreen({super.key});

  @override
  State<PromodoroScreen> createState() => _PromodoroScreenState();
}

class _PromodoroScreenState extends State<PromodoroScreen> {
  bool isVisible = true;

  Widget build(BuildContext context) {
    final provider = Provider.of<TimerService>(context);

    return Container(
      color: renderColor(provider.currentstate),
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                height: 70,
                child: Image.asset("assets/images/learnpomo.png"),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 30),
                child: IconButton(
                  onPressed: () {
                    setState(() {
                      isVisible = !isVisible;
                    });
                  },
                  icon: Icon(
                    Icons.info,
                    color: const Color.fromARGB(255, 121, 121, 121),
                    size: 30,
                  ),
                ),
              )
            ],
          ),
          const SizedBox(
            height: 3,
          ),
          Visibility(
            visible: isVisible,
            child: IconButton(
              onPressed: () {},
              icon: Container(
                height: 180,
                width: 380,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage(
                      "assets/images/about.png",
                    ),
                  ),
                ),
              ),
            ),
          ),
          TimerCard(),
          const SizedBox(
            height: 35,
          ),
          TimeOptions(),
          const SizedBox(
            height: 40,
          ),
          TimeController(),
          const SizedBox(
            height: 30,
          ),
          ProgressWidget(),
          SizedBox(
            height: 30,
          ),
          PlayPauseButton(),
          SizedBox(
            height: 7,
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  onPressed: () {
                    // Navigator.pop(context);
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => XOgame()));
                  },
                  icon: Container(
                    width: 180,
                    height: 120,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage("assets/images/game.png"),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    // Navigator.pop(context);
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => PlayChess()));
                  },
                  icon: Container(
                    width: 180,
                    height: 120,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage("assets/images/gamechess.png"),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
