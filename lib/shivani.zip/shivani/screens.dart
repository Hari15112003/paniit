import 'package:flutter/material.dart';
import 'package:name/shivani/widgets/chess.dart';
import 'package:name/shivani/widgets/progress.dart';
import 'package:name/shivani/widgets/timecontroller.dart';
import 'package:name/shivani/widgets/timrservice.dart';
import 'package:name/shivani/widgets/xogame.dart';
import 'package:name/widgets/playit.dart';

import 'package:provider/provider.dart';
import 'utils.dart';

import 'dart:async';

import 'widgets/timeoptions.dart';
import 'widgets/timercard.dart';

class PromodoroScreen extends StatefulWidget {
  const PromodoroScreen({super.key});

  @override
  State<PromodoroScreen> createState() => _PromodoroScreenState();
}

class _PromodoroScreenState extends State<PromodoroScreen> {
  bool isVisible = true;

  Widget build(BuildContext context) {
    final provider = Provider.of<TimerService>(context);

    return Container(
      color: renderColor(provider.currentstate),
      alignment: Alignment.center,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            height: 50,
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              SizedBox(
                height: 70,
                child: Image.asset("assets/images/learnpomo.png"),
              ),
              Padding(
                padding: const EdgeInsets.only(right: 30),
                child: IconButton(
                  onPressed: () {
                    setState(() {
                      isVisible = !isVisible;
                    });
                  },
                  icon: Icon(
                    Icons.info,
                    color: const Color.fromARGB(255, 121, 121, 121),
                    size: 30,
                  ),
                ),
              )
            ],
          ),
          const SizedBox(
            height: 3,
          ),
          Visibility(
            visible: isVisible,
            child: IconButton(
              onPressed: () {},
              icon: Container(
                height: 180,
                width: 380,
                decoration: BoxDecoration(
                  image: DecorationImage(
                    fit: BoxFit.fill,
                    image: AssetImage(
                      "assets/images/about.png",
                    ),
                  ),
                ),
              ),
            ),
          ),
          TimerCard(),
          const SizedBox(
            height: 35,
          ),
          TimeOptions(),
          const SizedBox(
            height: 40,
          ),
          TimeController(),
          const SizedBox(
            height: 30,
          ),
          ProgressWidget(),
          SizedBox(
            height: 30,
          ),
          // PlayPauseButton(),
          SizedBox(
            height: 7,
          ),
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                IconButton(
                  onPressed: () {
                    // Navigator.pop(context);
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => XOgame()));
                  },
                  icon: Container(
                    width: 180,
                    height: 120,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage("assets/images/game.png"),
                      ),
                    ),
                  ),
                ),
                IconButton(
                  onPressed: () {
                    // Navigator.pop(context);
                    Navigator.of(context).push(
                        MaterialPageRoute(builder: (context) => PlayChess()));
                  },
                  icon: Container(
                    width: 180,
                    height: 120,
                    decoration: BoxDecoration(
                      image: DecorationImage(
                        fit: BoxFit.fill,
                        image: AssetImage("assets/images/gamechess.png"),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
