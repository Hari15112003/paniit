import 'package:flutter/material.dart';
import 'dart:math';

import '../../utilities/utils.dart';

class QuoteShow extends StatelessWidget {
  const QuoteShow({super.key});

  @override
  Widget build(BuildContext context) {
    var randomItem = (Quotes..shuffle()).first;
    return SingleChildScrollView(
      child: FittedBox(
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 19, vertical: 15),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.all(Radius.circular(10.0)),
            color: Color.fromARGB(66, 0, 44, 190).withOpacity(.15)
            // gradient: LinearGradient(
            //     begin: Alignment.topLeft,
            //     end: Alignment.bottomRight,
            //     colors: [
            //       Color.fromARGB(66, 0, 44, 190).withOpacity(.4),
            //       Color.fromARGB(66, 89, 110, 179).withOpacity(.2)
            //     ]),
          ),
          child: Text(
            randomItem,
            style: textStyle1(
                15, const Color.fromARGB(255, 5, 3, 3), FontWeight.w600),
          ),
        ),
      ),
    );
  }
}
