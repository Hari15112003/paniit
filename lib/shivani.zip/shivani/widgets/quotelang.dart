import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:name/shivani/utils.dart';

class Quoter extends StatelessWidget {
  Quoter({Key? key}) : super(key: key);

 final List<Map<String, String>> quotes = [
  {
    'quote': "If people are not laughing at your goals, your goals are too small.",
    'author': '~Azim Premji',
  },
  {
    'quote':
        "Reading an hour a day is only 4% of your day. But that 4% will put you at the top of your field within 10 years. Find the time.",
    'author': '~Patrick Bet-David',
  },
  {
    'quote': "If you're serious about changing your life, you'll find a way. If not, you'll find an excuse.",
    'author': '~Jen Sincero',
  },
  {
    'quote': "Procrastination will delay your dreams.",
    'author': '~Vex King',
  },
  {
    'quote': "If it isn't a clear yes, then it's a clear no.",
    'author': '~Greg McKeown',
  },
  {
    'quote': "You are what you eat and read.",
    'author': '~Maya Corrigan',
  },
  {
    'quote': "Only staying active will make you want to live a hundred years.",
    'author': '~Japanese Proverb',
  },
  {
    'quote': "Some people die at 25 and aren't buried until 75.",
    'author': '~Benjamin Franklin',
  },
  {
    'quote': "Do whatever it takes as long as it takes.",
    'author': '~Balaji Rajendran',
  },
  {
    'quote': "Don't wait for the perfect moment. Take the moment and make it perfect.",
    'author': '~Zoey Sayward',
  },
  {
    'quote': "The only limit to our realization of tomorrow will be our doubts of today.",
    'author': '~Franklin D. Roosevelt',
  },
  {
    'quote': "The future belongs to those who believe in the beauty of their dreams.",
    'author': '~Eleanor Roosevelt',
  },
  {
    'quote': "Success is not the key to happiness. Happiness is the key to success.",
    'author': '~Albert Schweitzer',
  },
  {
    'quote': "Believe you can and you're halfway there.",
    'author': '~Theodore Roosevelt',
  },
  {
    'quote': "The only way to do great work is to love what you do.",
    'author': '~Steve Jobs',
  },
  {
    'quote': "The only person you are destined to become is the person you decide to be.",
    'author': '~Ralph Waldo Emerson',
  },
  {
    'quote': "Success is stumbling from failure to failure with no loss of enthusiasm.",
    'author': '~Winston S. Churchill',
  },
  {
    'quote': "Your time is limited, don't waste it living someone else's life.",
    'author': '~Steve Jobs',
  },
  {
    'quote': "Challenges are what make life interesting and overcoming them is what makes life meaningful.",
    'author': '~Joshua J. Marine',
  },
  {
    'quote': "The only way to achieve the impossible is to believe it is possible.",
    'author': '~Charles Kingsleigh (Alice in Wonderland)',
  },
  {
    'quote': "Dreams don't work unless you do.",
    'author': '~John C. Maxwell',
  },
  {
    'quote': "It's not the load that breaks you down, it's the way you carry it.",
    'author': '~Lou Holtz',
  },
  {
    'quote': "The only limit to our realization of tomorrow will be our doubts of today.",
    'author': '~Franklin D. Roosevelt',
  },
  {
    'quote': "The future belongs to those who believe in the beauty of their dreams.",
    'author': '~Eleanor Roosevelt',
  },
  {
    'quote': "Success is not the key to happiness. Happiness is the key to success.",
    'author': '~Albert Schweitzer',
  },
  {
    'quote': "Believe you can and you're halfway there.",
    'author': '~Theodore Roosevelt',
  },
  {
    'quote': "The only way to do great work is to love what you do.",
    'author': '~Steve Jobs',
  },
  {
    'quote': "The only person you are destined to become is the person you decide to be.",
    'author': '~Ralph Waldo Emerson',
  },
  {
    'quote': "Success is stumbling from failure to failure with no loss of enthusiasm.",
    'author': '~Winston S. Churchill',
  },
  {
    'quote': "Your time is limited, don't waste it living someone else's life.",
    'author': '~Steve Jobs',
  },
  {
    'quote': "Challenges are what make life interesting and overcoming them is what makes life meaningful.",
    'author': '~Joshua J. Marine',
  },
  {
    'quote': "The only way to achieve the impossible is to believe it is possible.",
    'author': '~Charles Kingsleigh (Alice in Wonderland)',
  },
  {
    'quote': "Dreams don't work unless you do.",
    'author': '~John C. Maxwell',
  },
  {
    'quote': "It's not the load that breaks you down, it's the way you carry it.",
    'author': '~Lou Holtz',
  },
  {
    'quote': "Life is 10% what happens to us and 90% how we react to it.",
    'author': '~Charles R. Swindoll',
  },
  {
    'quote': "The only place where success comes before work is in the dictionary.",
    'author': '~Vidal Sassoon',
  },
  {
    'quote': "Don't watch the clock; do what it does. Keep going.",
    'author': '~Sam Levenson',
  },
  {
    'quote': "The way to get started is to quit talking and begin doing.",
    'author': '~Walt Disney',
  },
  {
    'quote': "Your present circumstances don't determine where you can go; they merely determine where you start.",
    'author': '~Nido Qubein',
  },
  {
    'quote': "The only person you are destined to become is the person you decide to be.",
    'author': '~Ralph Waldo Emerson',
  },
  {
    'quote': "The only limit to our realization of tomorrow will be our doubts of today.",
    'author': '~Franklin D. Roosevelt',
  },
  {
    'quote': "The future belongs to those who believe in the beauty of their dreams.",
    'author': '~Eleanor Roosevelt',
  },
  {
    'quote': "Success is not the key to happiness. Happiness is the key to success.",
    'author': '~Albert Schweitzer',
  },
  {
    'quote': "Believe you can and you're halfway there.",
    'author': '~Theodore Roosevelt',
  },
  {
    'quote': "The only way to do great work is to love what you do.",
    'author': '~Steve Jobs',
  },
  {
    'quote': "The only person you are destined to become is the person you decide to be.",
    'author': '~Ralph Waldo Emerson',
  },
  {
    'quote': "Success is stumbling from failure to failure with no loss of enthusiasm.",
    'author': '~Winston S. Churchill',
  },
  {
    'quote': "Your time is limited, don't waste it living someone else's life.",
    'author': '~Steve Jobs',
  },
  {
    'quote': "Challenges are what make life interesting and overcoming them is what makes life meaningful.",
    'author': '~Joshua J. Marine',
  },
  {
    'quote': "The only way to achieve the impossible is to believe it is possible.",
    'author': '~Charles Kingsleigh (Alice in Wonderland)',
  },
  {
    'quote': "Dreams don't work unless you do.",
    'author': '~John C. Maxwell',
  },
  {
    'quote': "It's not the load that breaks you down, it's the way you carry it.",
    'author': '~Lou Holtz',
  },
  {
    'quote': "Life is 10% what happens to us and 90% how we react to it.",
    'author': '~Charles R. Swindoll',
  },
  {
    'quote': "The only place where success comes before work is in the dictionary.",
    'author': '~Vidal Sassoon',
  },
  {
    'quote': "Don't watch the clock; do what it does. Keep going.",
    'author': '~Sam Levenson',
  },
  {
    'quote': "The way to get started is to quit talking and begin doing.",
    'author': '~Walt Disney',
  },
  {
    'quote': "Your present circumstances don't determine where you can go; they merely determine where you start.",
    'author': '~Nido Qubein',
  },
];



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        elevation: 0,
        backgroundColor: Colors.transparent,
        title: Text(
          "Quote Time",
          style: textStyle1(23, Colors.white, FontWeight.w200),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFF439dab),
              Color(0xFFb576c2),
            ],
            begin: Alignment.topRight,
            end: Alignment.bottomLeft,
          ),
        ),
        child: Scrollbar(
          child: ListView.builder(
            scrollDirection: Axis.vertical,
            itemCount: quotes.length,
            itemBuilder: (context, index) {
              return Padding(
                padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 20),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(15),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
                    child: Container(
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(15),
                        border: Border.all(color: Colors.white, width: 0.5),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            "\"${quotes[index]['quote']}\"",
                            textAlign: TextAlign.justify,
                            style: TextStyle(
                              fontSize: 17,
                              color: Colors.white,
                              fontStyle: FontStyle.italic,
                              fontWeight: FontWeight.bold,
                              shadows: [
                                Shadow(
                                  blurRadius: 2.0,
                                  color: Colors.black.withOpacity(0.2),
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 5),
                          Text(
                            quotes[index]['author']!,
                            textAlign: TextAlign.end,
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              shadows: [
                                Shadow(
                                  blurRadius: 2.0,
                                  color: Colors.black.withOpacity(0.2),
                                  offset: Offset(1, 1),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
