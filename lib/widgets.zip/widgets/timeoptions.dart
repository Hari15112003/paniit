import 'package:flutter/material.dart';
import 'package:name/widgets/timrservice.dart';
import 'package:provider/provider.dart';

import '../utilities/utils.dart';

class TimeOptions extends StatelessWidget {
  const TimeOptions({super.key});

  //double selectedTime = 1500;

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TimerService>(context);
    return SingleChildScrollView(
      controller: ScrollController(initialScrollOffset: 230),
      scrollDirection: Axis.horizontal,
      child: Row(
          children: selectableTimes.map((time) {
        return InkWell(
          onTap: () => provider.selectTime(double.parse(time)),
          child: Container(
            margin: EdgeInsets.only(left: 8),
            width: 70,
            height: 40,
            decoration: int.parse(time) == provider.selectedTime
                ? BoxDecoration(
                    color: Colors.blue[800],
                    borderRadius: BorderRadius.circular(5),
                  )
                : BoxDecoration(
                    border: Border.all(
                        width: 1.5, color: Colors.blueGrey),
                    borderRadius: BorderRadius.circular(5),
                  ),
            child: Center(
              child: Text(
                (int.parse(time) ~/ 60).toString(),
                style: textStyle(
                    20,
                    int.parse(time) == provider.selectedTime
                        ? Colors.white
                        : Colors.black87,
                    FontWeight.w500),
              ),
            ),
          ),
        );
      }).toList()),
    );
  }
}
