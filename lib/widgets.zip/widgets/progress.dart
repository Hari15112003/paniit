import 'package:flutter/material.dart';
import 'package:name/widgets/timrservice.dart';
import 'package:provider/provider.dart';

import '../utilities/utils.dart';

class ProgressWidget extends StatelessWidget {
  const ProgressWidget({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<TimerService>(context);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        Container(
            height: 70,
            width: 150,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(7),
                border: Border.all(width: 2, color: Colors.black54)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Text(
                  "${provider.rounds}/4",
                  style: textStyle(20, Colors.black, FontWeight.bold),
                ),
                Text(
                  "ROUND",
                  style: textStyle(20, Colors.black45, FontWeight.bold),
                ),
              ],
            )),
        Container(
            height: 70,
            width: 150,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(7),
                border: Border.all(width: 2, color: Colors.black54)),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: [
                Text(
                  "${provider.goal}/12",
                  style: textStyle(20, Colors.black, FontWeight.bold),
                ),
                Text(
                  "GOAL",
                  style: textStyle(20, Colors.black45, FontWeight.bold),
                ),
              ],
            )),
      ],
    );

    // Row(
    //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    //   children: [
    //     Text(
    //       "${provider.rounds}/4",
    //       style: textStyle(20, Colors.black, FontWeight.bold),
    //     ),
    //     Text(
    //       "${provider.goal}/12",
    //       style: textStyle(20, Colors.black, FontWeight.bold),
    //     ),
    //   ],
    // ),
    // SizedBox(
    //   height: 10,
    // ),
    // Row(
    //   mainAxisAlignment: MainAxisAlignment.spaceEvenly,
    //   children: [
    //     Text(
    //       "ROUND",
    //       style: textStyle(20, Colors.black45, FontWeight.bold),
    //     ),
    //     Text(
    //       "GOAL",
    //       style: textStyle(20, Colors.black45, FontWeight.bold),
    //     ),
    //   ],
    // )
  }
}
